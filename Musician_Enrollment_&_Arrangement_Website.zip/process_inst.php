<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $instrument_name = $_POST["instrument_name"];
    $instrument_key = $_POST["instrument_key"];

    // Check if the instrument name already exists in the database
    $check_query = "SELECT * FROM instrument WHERE instrument_name = '$instrument_name'";
    $result = $conn->query($check_query);

    if ($result->num_rows > 0) {
        echo "Instrument already exists in the database.";
    } else {
        // Generate the instrument ID (assuming it's auto-generated)
        $instrument_id = generateInstrumentID();

        // Prepare and execute the SQL statement to insert the data into the database
        $insert_query = "INSERT INTO instrument (instrument_id, instrument_name, instrument_key) VALUES ('$instrument_id', '$instrument_name', '$instrument_key')";

        if ($conn->query($insert_query) === TRUE) {
            echo "Data stored in the database successfully.";
        } else {
            echo "Error: " . $insert_query . "<br>" . $conn->error;
        }

        // Display the submitted data
        echo "<h2>Submitted Data</h2>";
        echo "Instrument ID: " . $instrument_id . "<br>";
        echo "Instrument Name: " . $instrument_name . "<br>";
        echo "Instrument Key: " . $instrument_key . "<br>";
    }
}

function generateInstrumentID() {
    // Implement your own logic to generate the instrument ID
    // Example: You can retrieve the last inserted ID from the database and increment it by 1
    // Modify this function based on your requirements
    global $conn;
    $sql = "SELECT MAX(instrument_id) AS max_id FROM instrument";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $max_id = $row['max_id'];
    return ($max_id !== null) ? ($max_id + 2) : 51;
}

// Close the database connection
$conn->close();
?>