-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2023 at 07:42 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `records`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ad_name` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ad_name`, `password`) VALUES
('Nisha_Mishra', 'Nisha@22'),
('Soniya_Shil', 'Soniya@29'),
('Sudipto_Udy', 'Sudipto@18');

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `album_id` bigint(40) NOT NULL,
  `album_title` varchar(255) NOT NULL,
  `copyright_date` date NOT NULL,
  `format` varchar(50) NOT NULL,
  `producer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` (`album_id`, `album_title`, `copyright_date`, `format`, `producer`) VALUES
(1, 'Nevermind', '1991-09-24', 'D.V.D', 'Nirvana'),
(2, 'Praktan', '2016-05-27', 'C.D.', 'Shreya Ghosal'),
(3, 'Reputation', '2017-09-17', 'CD', 'Taylor Swift');

-- --------------------------------------------------------

--
-- Table structure for table `instrument`
--

CREATE TABLE `instrument` (
  `instrument_name` varchar(40) NOT NULL,
  `instrument_key` varchar(10) NOT NULL,
  `instrument_id` bigint(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instrument`
--

INSERT INTO `instrument` (`instrument_name`, `instrument_key`, `instrument_id`) VALUES
('Guitar', 'C major', 51),
('Base Guitar', 'A major', 53),
('Ukulele', 'G major', 55),
('Octopad', 'A#', 57),
('sitar', 'g minor', 59),
('keyboard', 'f sharp', 61),
('violin', 'c sharp', 63),
('Harmonium', 'b flat', 65),
('flute', 'E', 67);

-- --------------------------------------------------------

--
-- Table structure for table `musician`
--

CREATE TABLE `musician` (
  `name` varchar(100) NOT NULL,
  `ssn` int(40) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone_no` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `musician`
--

INSERT INTO `musician` (`name`, `ssn`, `address`, `phone_no`) VALUES
('Nisha Mishra', 1, 'Boral, Garia, Kolkata', 8420538040),
('Sudipto Chatterjee', 2, 'Banerjee Para, Joynagar\r\nSouth 24 Parganas', 6294179797),
('Anwesha Paul', 3, 'Shahid Nagar', 9945372857),
('Sovon Nag', 4, 'Golfgreen', 8759362485),
('Chayanika Roy', 5, 'avishikta', 7125964832),
('Soniya Shil', 6, 'Ganguli pukur', 8777026453),
('Shyamananda Chowdhury', 7, 'Haltu', 8856294571),
('Dipayan Sharma', 8, 'Jhil road', 9574128362);

-- --------------------------------------------------------

--
-- Table structure for table `musician_inst`
--

CREATE TABLE `musician_inst` (
  `ssn` int(40) NOT NULL,
  `instrument_id` bigint(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `musician_inst`
--

INSERT INTO `musician_inst` (`ssn`, `instrument_id`) VALUES
(1, 55),
(2, 51),
(2, 55),
(3, 53),
(3, 61),
(4, 53),
(4, 55),
(4, 65),
(5, 55),
(5, 59),
(5, 67),
(6, 61),
(6, 65),
(7, 63),
(8, 55),
(8, 67);

-- --------------------------------------------------------

--
-- Table structure for table `performance`
--

CREATE TABLE `performance` (
  `ssn` int(11) NOT NULL,
  `song_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performance`
--

INSERT INTO `performance` (`ssn`, `song_id`) VALUES
(1, 3),
(2, 9),
(3, 4),
(4, 10),
(5, 12),
(6, 8),
(7, 14),
(8, 9);

-- --------------------------------------------------------

--
-- Table structure for table `produces`
--

CREATE TABLE `produces` (
  `ssn` int(40) NOT NULL,
  `album_id` bigint(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produces`
--

INSERT INTO `produces` (`ssn`, `album_id`) VALUES
(1, 1),
(2, 2),
(3, 1),
(4, 2),
(5, 3),
(6, 2),
(7, 3),
(8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `song`
--

CREATE TABLE `song` (
  `song_id` int(40) NOT NULL,
  `song_title` varchar(150) NOT NULL,
  `author` varchar(150) NOT NULL,
  `album_id` bigint(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `song`
--

INSERT INTO `song` (`song_id`, `song_title`, `author`, `album_id`) VALUES
(1, 'Polly', 'Nirvana', 1),
(2, 'On a Plain', 'Nirvana', 1),
(3, 'Something In the way', 'Nirvana', 1),
(4, 'Drain You', 'Nirvana', 1),
(5, 'Breed', 'Nirvana', 1),
(6, 'Kolkata', 'Shreya Ghosal', 2),
(7, 'Bhromor', 'Surajit Chatterjee', 2),
(8, 'Tumi Jake Bhalobasho', 'Anupam Roy', 2),
(9, 'Moner Guptachar', 'Anindya Chatterjee', 2),
(10, 'Moner Manus', 'Bikram Ghosh', 2),
(11, 'End Game', 'Taylor Swift', 3),
(12, 'Getaway car', 'Taylor Swift', 3),
(13, 'Ready for it', 'Taylor Swift', 3),
(14, 'Look what you made me do', 'Taylor Swift', 3),
(15, 'Kind of my heart', 'Taylor Swift', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`password`);

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`album_id`);

--
-- Indexes for table `instrument`
--
ALTER TABLE `instrument`
  ADD PRIMARY KEY (`instrument_id`);

--
-- Indexes for table `musician`
--
ALTER TABLE `musician`
  ADD PRIMARY KEY (`ssn`);

--
-- Indexes for table `musician_inst`
--
ALTER TABLE `musician_inst`
  ADD PRIMARY KEY (`ssn`,`instrument_id`),
  ADD KEY `fk_musician_inst_instrument` (`instrument_id`);

--
-- Indexes for table `performance`
--
ALTER TABLE `performance`
  ADD PRIMARY KEY (`ssn`,`song_id`),
  ADD KEY `song_id` (`song_id`);

--
-- Indexes for table `produces`
--
ALTER TABLE `produces`
  ADD PRIMARY KEY (`ssn`,`album_id`),
  ADD KEY `fk_produces_albums` (`album_id`);

--
-- Indexes for table `song`
--
ALTER TABLE `song`
  ADD PRIMARY KEY (`song_id`),
  ADD KEY `fk_song_albums` (`album_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `song`
--
ALTER TABLE `song`
  MODIFY `song_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `musician_inst`
--
ALTER TABLE `musician_inst`
  ADD CONSTRAINT `fk_musician_inst_instrument` FOREIGN KEY (`instrument_id`) REFERENCES `instrument` (`instrument_id`),
  ADD CONSTRAINT `fk_musician_inst_musician` FOREIGN KEY (`ssn`) REFERENCES `musician` (`ssn`);

--
-- Constraints for table `performance`
--
ALTER TABLE `performance`
  ADD CONSTRAINT `performance_ibfk_1` FOREIGN KEY (`ssn`) REFERENCES `musician` (`ssn`),
  ADD CONSTRAINT `performance_ibfk_2` FOREIGN KEY (`song_id`) REFERENCES `song` (`song_id`);

--
-- Constraints for table `produces`
--
ALTER TABLE `produces`
  ADD CONSTRAINT `fk_produces_albums` FOREIGN KEY (`album_id`) REFERENCES `albums` (`album_id`),
  ADD CONSTRAINT `fk_produces_musician` FOREIGN KEY (`ssn`) REFERENCES `musician` (`ssn`);

--
-- Constraints for table `song`
--
ALTER TABLE `song`
  ADD CONSTRAINT `fk_song_albums` FOREIGN KEY (`album_id`) REFERENCES `albums` (`album_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
