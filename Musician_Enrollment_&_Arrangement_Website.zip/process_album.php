<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $album_title = $_POST["album_title"];
    $copyright_date = $_POST["copyright_date"];
    $format = $_POST["format"];
    $producer = $_POST["producer"];
    $song_ids = array(
        $_POST["song_id1"],
        $_POST["song_id2"],
        $_POST["song_id3"],
        $_POST["song_id4"],
        $_POST["song_id5"]
    );

    // Generate the album ID (assuming it's auto-generated)
    $album_id = generateAlbumID();

    // Prepare and execute the SQL statement using a prepared statement
    $sql = "INSERT INTO albums (album_id, album_title, copyright_date, format, producer) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issss", $album_id, $album_title, $copyright_date, $format, $producer);

    if ($stmt->execute()) {
        echo "Album data stored in the database successfully. <br>";

        // Associate the songs with the album
        foreach ($song_ids as $song_id) {
            // Check if the song ID is already associated with another album
            $sql = "SELECT * FROM song WHERE song_id = ? AND album_id IS NOT NULL";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $song_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "Error: Song ID $song_id is already associated with another album. <br>";
            } else {
                // Prepare and execute the SQL statement to update the album ID for the song in the database
                $sql = "UPDATE song SET album_id = ? WHERE song_id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $album_id, $song_id);

                if ($stmt->execute()) {
                    echo "Song ID: $song_id associated with Album ID: $album_id. <br>";
                } else {
                    echo "Error associating Song ID: $song_id with Album ID: $album_id. Error: " . $stmt->error . "<br>";
                }
            }
        }
    } else {
        echo "Error storing album data in the database. Error: " . $stmt->error . "<br>";
    }
}

function generateAlbumID() {
    // Implement your own logic to generate the album ID
    // Example: You can retrieve the last inserted ID from the database and increment it by 1
    // Modify this function based on your requirements
    global $conn;
    $sql = "SELECT MAX(album_id) AS max_id FROM albums";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $max_id = $row['max_id'];
    return ($max_id !== null) ? ($max_id + 1) : 1;
}

// Close the database connection
$conn->close();
